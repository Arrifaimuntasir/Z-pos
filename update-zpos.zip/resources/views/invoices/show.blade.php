@extends('layouts.admin')

@section('title', 'Invoice')

@section('content')
<div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center mb-4 gap-3 d-print-none">
    <div>
        <h4 class="fw-bold mb-0 text-dark">{{ __('Invoice') }}</h4>
        <span class="text-muted small">{{ __('View transaction details') }}</span>
    </div>
    <div>
        
        <a href="{{ route('sales.returns.create', $invoice->id) }}" class="btn btn-warning px-3 shadow-sm text-dark" style="border-radius: 8px;">
            <i class="bi bi-arrow-return-left me-1"></i> {{ __('Return/Refund') }}
        </a>
        <button onclick="shareInvoice(event)" class="btn btn-success px-3 shadow-sm" style="border-radius: 8px;">
            <i class="bi bi-share me-1"></i> {{ __('Share') }}
        </button>
        <a href="{{ route('invoices.pdf', $invoice->id) }}?v={{ time() }}" class="btn btn-danger px-3 shadow-sm" style="border-radius: 8px;">
            <i class="bi bi-file-earmark-pdf me-1"></i> {{ __('PDF') }}
        </a>
        <button onclick="window.print()" class="btn btn-primary px-3 shadow-sm" style="border-radius: 8px;">
            <i class="bi bi-printer me-1"></i> {{ __('Print') }}
        </button>
    </div>
</div>

<script>
async function shareInvoice(event) {
    if (!navigator.share || !navigator.canShare) {
        alert('Samahani, kifaa chako hakisupport kushare file moja kwa moja. Tafadhali download PDF kisha ushare.');
        return;
    }

    const btn = event.currentTarget;
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Inandaa...';
    btn.disabled = true;

    try {
        const pdfUrl = "{{ route('invoices.pdf', $invoice->id) }}";
        const response = await fetch(pdfUrl);
        const blob = await response.blob();
        
        const file = new File([blob], "Invoice-{{ $invoice->reference_no }}.pdf", { type: 'application/pdf' });
        
        if (navigator.canShare({ files: [file] })) {
            await navigator.share({
                title: 'Invoice {{ $invoice->reference_no }}',
                files: [file]
            });
        } else {
            alert('Kifaa chako hakisupport kushare file hili.');
        }
    } catch (error) {
        console.error('Error sharing:', error);
        alert('Kuna tatizo limetokea. Tafadhali download PDF badala yake.');
    } finally {
        btn.innerHTML = originalHtml;
        btn.disabled = false;
    }
}
</script>

<div class="row justify-content-center">
    <div class="col-12 col-xl-10">
        <div class="card border-0 shadow-sm" style="border-radius: 16px;">
            <div class="card-body p-5" id="invoiceArea">
                
                <!-- Receipt Header -->
                <div class="text-center border-bottom pb-4 mb-4">
                    <h2 class="fw-bold text-dark mb-1">{{ $invoice->shop->name ?? 'Z-POS SYSTEM' }}</h2>
                    <p class="text-muted mb-0">{{ $invoice->shop->address ?? 'Dar es Salaam, Tanzania' }}</p>
                    <p class="text-muted mb-0">Tel: {{ $invoice->shop->phone ?? '+255 123 456 789' }}</p>

                </div>

                <!-- Receipt Info -->
                <div class="row mb-4">
                    <div class="col-sm-6">
                        <h6 class="fw-bold text-muted small text-uppercase mb-1">{{ __('Billed To:') }}</h6>
                        @if($invoice->customer)
                            <h5 class="fw-bold mb-0">{{ $invoice->customer->name }}</h5>
                            @if($invoice->customer->phone) <p class="text-muted mb-0">{{ $invoice->customer->phone }}</p> @endif
                            @if($invoice->customer->address) <p class="text-muted mb-0">{{ $invoice->customer->address }}</p> @endif
                        @else
                            <h5 class="fw-bold mb-0 text-muted fst-italic">{{ __('Walk-in Customer') }}</h5>
                        @endif
                    </div>
                    <div class="col-sm-6 text-sm-end mt-4 mt-sm-0">
                        <h6 class="fw-bold text-muted small text-uppercase mb-1">{{ __('Invoice Details:') }}</h6>
                        <h5 class="fw-bold text-primary mb-1">{{ $invoice->reference_no }}</h5>
                        <p class="text-muted mb-0">Date: {{ \Carbon\Carbon::parse($invoice->sale_date)->format('d M Y') }}</p>
                        <p class="text-muted mb-0">Method: {{ $invoice->payment_method }}</p>
                    </div>
                </div>

                <!-- Items Table -->
                <div class="table-responsive mb-4">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="text-center" style="width: 50px;">#</th>
                                <th>{{ __('Product Name') }}</th>
                                <th class="text-center" style="width: 100px;">{{ __('Qty') }}</th>
                                <th class="text-end" style="width: 150px;">{{ __('Price') }}</th>
                                <th class="text-end" style="width: 150px;">{{ __('Total') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($invoice->items as $index => $item)
                                @if($item->net_quantity > 0)
                                <tr>
                                    <td class="text-center">{{ $index + 1 }}</td>
                                    <td>
                                        <span class="fw-medium">{{ $item->product ? $item->product->name : 'Unknown Product' }}</span>
                                    </td>
                                    <td class="text-center">{{ $item->net_quantity }}</td>
                                    <td class="text-end">{{ number_format($item->unit_price) }}</td>
                                    <td class="text-end fw-bold">{{ number_format($item->net_total) }}</td>
                                </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Totals -->
                <div class="row justify-content-end">
                    <div class="col-sm-5">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted fw-medium">{{ __('Subtotal:') }}</span>
                            <span class="fw-bold">{{ number_format($invoice->net_total_amount) }} TSh</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 pb-2 border-bottom">
                            <span class="text-muted fw-medium">{{ __('Discount:') }}</span>
                            <span class="fw-bold">0 TSh</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span class="fs-5 fw-bold text-dark">{{ __('Grand Total:') }}</span>
                            <span class="fs-5 fw-bold text-primary">{{ number_format($invoice->net_total_amount) }} TSh</span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted fw-medium">{{ __('Amount Paid:') }}</span>
                            <span class="fw-bold text-success">{{ number_format($invoice->paid_amount) }} TSh</span>
                        </div>
                        @if($invoice->net_total_amount - $invoice->paid_amount > 0)
                            <div class="d-flex justify-content-between text-danger">
                                <span class="fw-medium">{{ __('Balance Due:') }}</span>
                                <span class="fw-bold">{{ number_format($invoice->net_total_amount - $invoice->paid_amount) }} TSh</span>
                            </div>
                        @endif
                    </div>
                </div>

                @if($invoice->notes)
                <div class="mt-4 pt-4 border-top">
                    <h6 class="fw-bold text-muted small text-uppercase mb-2">{{ __('Notes:') }}</h6>
                    <p class="text-muted mb-0">{{ $invoice->notes }}</p>
                </div>
                @endif

                <!-- Footer Advertisement -->
                <div class="text-center mt-5 pt-4 border-top">
                    <p class="text-muted small fst-italic mb-2">{{ $invoice->shop->receipt_message ?? 'Thank you for your business!' }}</p>
                    <p class="text-muted small mb-0" style="font-size: 0.8rem;">
                        <strong>{{ __('Powered by Z-POS SYSTEM') }}</strong> <br> {{ __('Smart Point of Sale & Inventory Management') }}
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>

<style>
@media print {
    body { background: white; }
    .wrapper { display: block; }
    .sidebar { display: none !important; }
    #content { margin: 0; padding: 0; width: 100%; min-height: auto; }
    .top-navbar, .d-print-none { display: none !important; }
    .card { box-shadow: none !important; border: none !important; }
    .card-body { padding: 0 !important; }
}
</style>
@endsection

