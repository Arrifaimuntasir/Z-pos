<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('shops') && !Schema::hasColumn('shops', 'theme')) {
            Schema::table('shops', function (Blueprint $table) {
                $table->string('theme', 20)->default('light')->after('receipt_paper_width');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('shops') && Schema::hasColumn('shops', 'theme')) {
            Schema::table('shops', function (Blueprint $table) {
                $table->dropColumn('theme');
            });
        }
    }
};
